#include <stdio.h>

int catalan(int n){
    int i, r = 0;
    if(n == 0) return 1;
    for (i = 0; i < n; i++)
		r += catalan(i) * catalan(n - 1 - i);
    return r;
}

int main () {
    int n;
    do {
        printf("Inserisci indice n del numero di Catalan voluto: ");
        scanf("%d", &n);
    } while(n< 0);

    printf("L'n-esimo numero di Catalan vale %d\n", catalan(n));
    return 0;
}
