#include <stdio.h>

int converti(int n, int b){
    if(n == 0 || b==10)
        return n;
    return (n % b) + 10*converti(n / b, b);
}

int main () {
    int num, base;
    do {
        printf("Inserisci numero da convertire: ");
        scanf("%d", &num);
    } while(num < 0);
    do {
        printf("Inserisci base di destinazione [2..10]: ");
        scanf("%d", &base);
    } while(base < 2 || base > 10);

    printf("%d in base %d vale %d\n", num, base, converti(num, base));
    return 0;
}
