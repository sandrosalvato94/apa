// questa versione realizza la coda come lista, caratterizzata da
// due puntatori: testa e fondo. Tali puntatori sono passati
// by reference (cioe' se ne passano i puntatori) alle funzioni
// di inserimento e di estrazione (che possono modificarli)

#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<ctype.h>

typedef struct nodo_ {
    char *codice;
    struct nodo_ *next;
} nodo;

nodo *crea_nodo(char *codice, nodo *next);
void accoda(char *codice, nodo **pTesta, nodo **pFondo);
nodo *estrai(nodo **pTesta, nodo **pFondo);
void stampa_coda(nodo *testa);
void stampa_nodo(nodo *n);
void libera_nodo(nodo *n);
void libera_coda_recur(nodo *n);
void libera_coda_iter(nodo *testa);

int main(int argc, char **argv) {

    char scelta[3], *s;
    int termina = 0;
    nodo *testa=NULL, *fondo=NULL;

    do {
        printf("Cosa vuoi fare?\n");
        printf("(I)nserisci in coda\n");
        printf("(E)strai dalla coda\n");
        printf("(S)tampa tutto\n");
        printf("(T)ermina\n");
        scanf("%s", scelta);
        for (s=scelta; !isalpha(*s); s++);
        switch (toupper(*s)) {
            case 'I': {
                char codice[11];
                printf("Inserisci codice della persona\n");
                scanf("%s", codice);
                accoda(codice, &testa, &fondo);
            }
            break;
            case 'E': {
              nodo *n = estrai(&testa, &fondo);
                // ... operazioni sul nodo ...
                stampa_nodo(n);
                libera_nodo(n);
            }
            break;
            case 'S':
                stampa_coda(testa);
            break;
            case 'T': {
                termina=1;
                libera_coda_iter(testa);
                // oppure
                // libera_coda_rec(testa);
            }
            break;
            default: printf ("Comando errato\n");
        }
    } while(!termina);

    return 0;
}

nodo *crea_nodo(char *codice, nodo *next) {
    nodo *n = malloc(1*sizeof(nodo));
    n->codice = strdup(codice);
    n->next = next;
    return n;
}


void accoda(char *codice, nodo **pTesta, nodo **pFondo) {
    if (*pTesta == NULL) {
        *pTesta = *pFondo = crea_nodo(codice, NULL);
    } else {
      (*pFondo)->next = crea_nodo(codice, NULL);
      *pFondo = (*pFondo)->next;
    }
}

nodo *estrai(nodo **pTesta, nodo **pFondo) {
    if (*pTesta == NULL) return NULL;
    nodo *tmp = *pTesta;
    *pTesta = tmp->next;
    if (*pTesta == NULL) *pFondo = NULL;
    return tmp;
}

void stampa_coda(nodo *testa) {
    nodo *tmp = testa;
    while(tmp != NULL) {
        stampa_nodo(tmp);
        tmp = tmp->next;
    }
}

void stampa_nodo(nodo *n) {
    printf("%s\n", n->codice);
}

void libera_nodo(nodo *n) {
    if (n == NULL) return;
    free(n->codice);
    free(n);
}

void libera_coda_recur(nodo *n) {
    if(n == NULL) return;
    libera_coda_recur(n->next);
    libera_nodo(n);
}

void libera_coda_iter(nodo *testa) {
    nodo *t, *u;
    for (t = testa; t != NULL; t = u) {
      u = t->next;
      libera_nodo(t);
    }
}
