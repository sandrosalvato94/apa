#include "item_string.h"

#define MAXC 20

item leggi(FILE *fp)
{
  item dato;
  char riga[MAXC];

  fscanf(fp, "%s", riga);
  dato = (item) malloc((strlen(riga)+1)*sizeof(char));
  if (dato == NULL)
    return NULL;

  strcpy(dato, riga);
  return dato;
}

void stampa(FILE *fp, item dato)
{
  fprintf(fp,"%s\n",dato);
}

int confronta(item d1, item d2)
{
  return strcmp(d1, d2);
}

void libera(item dato)
{
  free(dato);
}
