#ifndef _ITEM_INCLUDED
#define _ITEM_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* item;

item leggi(FILE *fp);
void stampa(FILE *fp, item d);
int confronta(item d1, item d2);
void libera(item d);


#endif
