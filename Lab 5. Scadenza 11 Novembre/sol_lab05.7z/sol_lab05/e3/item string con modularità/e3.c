#include<stdlib.h>
#include<string.h>
#include<stdio.h>

#include "item_string.h"

void mergesort(item *vett, int size);
void mergesort_r(item *vett, item *tmp, int p, int r);
void merge(item *vett, item *tmp, int p, int m, int r);
void stampa_tutto(item *vett, int size);

int main(int argc, char **argv) {

  int num_el = 0, i;
  item *vett;
  FILE *in = fopen(argv[1], "r");
  if (in == NULL)
    exit(-1);

  fscanf(in, "%d", &num_el);

  vett = (item*) malloc(num_el*sizeof(item));
  if (vett == NULL)
    exit(-1);

  for(i=0; i<num_el; i++)
    vett[i] = leggi(in);

  printf("Contenuti non ordinati...\n");
  stampa_tutto(vett, num_el);
  mergesort(vett, num_el);
  printf("Contenuti ordinati...\n");
  stampa_tutto(vett, num_el);

  return 0;
}

void stampa_tutto(item *vett, int size)
{
  int i;
  for(i=0;i<size;i++) stampa(stdout, vett[i]);
}

void mergesort(item *vett, int size)
{
  int l=0, r=size-1;
  item *tmp;

  tmp = (item *)malloc(size*sizeof(item));
  mergesort_r(vett, tmp, l, r);
  free(tmp);
}

void mergesort_r(item *vett, item *tmp, int l, int r)
{
  int q = (l + r)/2;
  if (r <= l)
    return;
  mergesort_r(vett, tmp, l, q);
  mergesort_r(vett, tmp, q+1, r);
  merge(vett, tmp, l, q, r);
}

void merge(item *vett, item *tmp, int l, int q, int r)
{
  int i, j, k;

  i = l;   j = q+1;
  for (k = l; k <= r; k++)
    if (i > q)
      tmp[k] = vett[j++];
    else if (j > r)
      tmp[k] = vett[i++];
    else if ( (confronta(vett[i], vett[j]) <= 0)  )
      tmp[k] = vett[i++];
    else
      tmp[k] = vett[j++];
  for ( k = l; k <= r; k++ )
    vett[k] = tmp[k];
  return;
}

