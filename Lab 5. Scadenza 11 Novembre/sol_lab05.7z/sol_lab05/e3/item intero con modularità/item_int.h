#ifndef _ITEM_INCLUDED
#define _ITEM_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef int item;

void leggi(FILE *fp, item *dp);
void stampa(FILE *fp, item d);
int confronta(item d1, item d2);
void libera(item d);

#endif
