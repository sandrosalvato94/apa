#include "item_int.h"
#define MAXC 50

void leggi(FILE *fp, item *dp)
{
  fscanf(fp,"%d",dp);
}

void stampa(FILE *fp, item dato)
{
  fprintf(fp,"%d\n",dato);
}

int confronta(item d1, item d2)
{
  return d1-d2;
}

void libera(item dato)
{
  return;
}
